Investigator HQ Responsive Background Pack
========================================
9:16   -> 1080x1920
9:18   -> 1080x2160
9:19.5 -> 1080x2340
9:20   -> 1080x2400
9:21   -> 1080x2520

Use the nearest aspect-ratio asset for the device.
Dynamic case titles, player counts, case images and buttons should be rendered programmatically above these backgrounds.
